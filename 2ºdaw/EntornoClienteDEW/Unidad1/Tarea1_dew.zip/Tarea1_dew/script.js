
        const saludar = () => {
            alert('LO SIENTO, NO NOS QUEDAN HAMBURGUESAS.');
        }